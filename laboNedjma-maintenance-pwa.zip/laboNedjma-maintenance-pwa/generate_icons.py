#!/usr/bin/env python3
"""Generate PWA icons for LaboNedjma Maintenance app."""
import struct, zlib, base64

def make_png(size, bg=(27,58,107), fg=(255,255,255)):
    """Create a simple PNG icon with a wrench symbol."""
    w, h = size, size
    img = []
    for y in range(h):
        row = []
        for x in range(w):
            # Background
            r, g, b = bg
            # Draw a simple gear/tool icon
            cx, cy = w/2, h/2
            dx, dy = x - cx, y - cy
            dist = (dx*dx + dy*dy) ** 0.5
            rad = w * 0.38
            inner = w * 0.20
            # Outer circle ring
            if inner < dist < rad:
                angle = (dx / (dist + 0.001))
                # Gear teeth pattern
                import math
                ang = math.atan2(dy, dx)
                teeth = 8
                tooth = (math.sin(ang * teeth) > 0.3)
                if dist < rad * (1.08 if tooth else 1.0):
                    r, g, b = fg
            # Inner circle (hub)
            elif dist < w * 0.10:
                r, g, b = fg
            # White "L" letter
            lx = x - int(w*0.3)
            ly = y - int(h*0.35)
            if 0 <= lx < int(w*0.08) and 0 <= ly < int(h*0.32):
                r, g, b = fg
            if 0 <= ly - int(h*0.28) < int(h*0.06) and 0 <= lx < int(w*0.20):
                r, g, b = fg
            row += [r, g, b, 255]
        img.append(row)
    return encode_png(img, w, h)

def encode_png(pixels, w, h):
    def chunk(name, data):
        c = zlib.crc32(name + data) & 0xffffffff
        return struct.pack('>I', len(data)) + name + data + struct.pack('>I', c)
    
    raw = b''
    for row in pixels:
        raw += b'\x00' + bytes(row)
    
    ihdr = struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0)
    idat = zlib.compress(raw, 9)
    
    return (b'\x89PNG\r\n\x1a\n' +
            chunk(b'IHDR', ihdr) +
            chunk(b'IDAT', idat) +
            chunk(b'IEND', b''))

import os
os.makedirs('icons', exist_ok=True)

for size in [192, 512]:
    png = make_png(size)
    with open(f'icons/icon-{size}.png', 'wb') as f:
        f.write(png)
    print(f'Generated icons/icon-{size}.png ({size}x{size})')

print('Icons generated successfully!')
